"""CartPilot: an agentic checkout MCP server (Channel3 product data + PayPal payments)."""

__version__ = "0.1.0"
